import pandas as pd
from pymongo import MongoClient
from datetime import datetime
from argparse import ArgumentParser
import traceback
import sys


def load_from_excel(input_file, tickers):
    '''
    This function reads option chain from given input excel file
    input_file -> input file where the data will be imported from
    tickers -> list of tickers to be loaded from the excel file
    '''
    opt_chains = {}
    for tick in tickers:
        opt_chains[tick] = pd.ExcelFile(input_file).parse(tick)
    return opt_chains


def save_to_excel(opt_chains, output_file):
    '''
    This function stores an option chain in given output excel file
    opt_chains -> dictionary of {ticker: dataframe}
    output_file -> output file where the data will be exported
    '''
    writer = pd.ExcelWriter(output_file)
    for ticker in opt_chains.keys():
        opt_chains[ticker].to_excel(writer, sheet_name=ticker)
    writer.save()


if __name__ == "__main__":
    # Configure the command line options
    parser = ArgumentParser()
    parser.add_argument('-t', '--tickers', nargs='+', required=True,
                        help='[Required] Determines a list of option tickers')
    parser.add_argument('-x', '--expiry', type=str, help=('Determines option '
                        'expiry date. Use format YYYYMM'))
    parser.add_argument('-s', '--strike', help='Determines option strike')
    parser.add_argument('-i', '--input', type=str,
                        help='Uses an excel file as input')
    parser.add_argument('-o', '--output', type=str,
                        help='Uses an excel file as output')
    parser.add_argument('-m', '--mongo', type=str,
                        help='Stores output data in given MongoDB database')

    args = parser.parse_args()
    df_option_chains = None

    # If input excel file was given, load data
    if args.input:
        df_option_chainss = load_from_excel(args.input, args.tickers)
    else:
        # Data will be loaded from Interactive Brokers server
        from ib_api import IB_API
        from time import sleep

        # Connection thread
        try:
            client_id = 0
            ib = None
            # Try connecting with secuential client_id values until using
            # one free id
            while True:
                try:
                    ib = IB_API(client_id=client_id)
                    ib.start()
                    sleep(1)
                    if ib.thread_exception_msg:
                        client_id += 1
                        continue
                    break
                except Exception, e:
                    print e
                    break

            for ticker in args.tickers:
                ib.get_stock_implied_volatility(ticker, True)
            ib.get_option_contracts(args.tickers)
            ib.join()  # Wait for the IB thread to finish

            if(len(ib.opt_chain) == 0):
                print('Error, zero contracts retrieved')
            else:
                # Store option chain in excel file
                if args.output:
                    # Get option chains from the IB connection class
                    df_option_chains = {t: pd.DataFrame(ib.opt_chain[t]).T
                                        for t in args.tickers}

                    # Get columns to be exported to excel file
                    for key in ib.opt_chain[args.tickers[0]]:
                        cols = ib.opt_chain[args.tickers[0]][key].keys()
                        break
                    for t in args.tickers:
                        # Set column names
                        df_option_chains[t] = df_option_chains[t][cols]
                        # Remove those option contracts without price
                        df_option_chains[t].dropna(subset=['close'])

                    # Save dataframe to Excel file
                    save_to_excel(df_option_chains, args.output)
                    print 'Successfully exported to ' + str(args.output)
                elif args.mongo:
                    # Store option chains in MongoDB database
                    con = MongoClient('localhost:27017')
                    db = args.mongo
                    today = datetime.now().replace(
                        hour=0, minute=0, second=0, microsecond=0)

                    for t in args.tickers:
                        # Store underlyings close price and IV
                        con[db]['underlyings'].insert(
                            {'ticker': t,
                             'last': ib.stk_data[t]['close'],
                             'iv': ib.stk_data[t]['iv'],
                             'timestamp': today})

                        # Store option contracts TODO under testing
                        con[db]['options'].insert([
                            {'ticker': t, 'contract_id': c['m_conId'],
                             'right': c['m_right'], 'strike': c['m_strike'],
                             'close': c['close'], 'expiry':
                             datetime.strptime(c['m_expiry'], '%Y%m%d'),
                             'multiplier': c['m_multiplier'],
                             'timestamp': today}
                            for c in ib.opt_chain[t].values() if c['close']
                        ])

                    print 'Successfully exported to Mongo database'

        except Exception, e:
            traceback.print_exc()
            print 'ERROR in IB_API: ' + str(e)
        finally:
            ib.disconnect()
            sys.exit()

        # Send e-mail report
        # TODO
